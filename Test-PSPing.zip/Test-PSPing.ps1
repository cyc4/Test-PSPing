﻿
[CmdLetBinding(DefaultParameterSetName="IPADDRESS")]
Param (
    
    [Parameter(ParameterSetName="IPADDRESS", Mandatory=$true, Position=0)]
    [ValidateScript({$_ -match [IPAddress]$_ })]    
    [string]$IPAddress,
    
    [Parameter(ParameterSetName="FQDN", Mandatory=$true, Position=0)]  
    [string]$FQDN,


    [Parameter(Mandatory=$true, Position=1)]
    [ValidateRange(0, 65535)]
    [string]$Port,
    
    [Parameter(Mandatory=$false)]
    [Alias("Output")]
    [ValidateScript({Test-Path $_})]    
	[string]$logpath=$env:temp,
    
    [int32]$Interval = 10,

    [Switch]$AsJob
)


# Start main scription

switch ($PSCmdlet.ParameterSetName) 
{
    "IPADDRESS" 
        {
            Write-Verbose "IP address from input: $IPAddress "
        }

    "FQDN"
        {
            try 
            {
                $fqdnObj = Resolve-DnsName $FQDN -Type A -ErrorAction Stop
            }
            catch 
            {
                Write-Host "Invalid input, $($Error[0])"  -ForegroundColor Red
                Exit -1
            }

            $IPAddress = $fqdnObj.IPAddress
            Write-Verbose "FQDN from input: $FQDN - resolved IP address: $IPAddress"
        }    
    Default {}
}

Write-Host "`nRunning PSPING TCP test to $IPAddress : $port every $Interval seconds. Logs erros to screen. Press <CTRL> C to stop. `n" -Fo Cyan




$scriptPath = $PSScriptRoot
Add-Type -Path "$scriptPath\Microsoft.ApplicationInsights.dll"  
function Write-AppInsigntTrace($content){

    $client = New-Object Microsoft.ApplicationInsights.TelemetryClient  
    $client.InstrumentationKey="17634d40-732f-4a34-854d-8ddc5d60148c"  
    $client.TrackTrace($content)   
    
}







# Get the full path of $logpath if it was provided as local path .\
$logpath = (Get-Item $logpath).FullName

# Set log file to $logpath, name with current time.
$logfile= Join-Path  $logpath $($env:COMPUTERNAME+"_PING_"+$IPAddress+"_"+$port+"_"+((get-date).ToUniversalTime()).ToString("yyyyMMddTHHmmss")+".log")
Write-host "Log File : "$logfile -Fo Cyan 

$killswitch=1
$failcount=0

$headline="TIMESTAMP,RESULT,DestIP,DestPort,Message,FailCount"
$headline |Out-File $logfile -Encoding utf8 

# PSPing.exe/PSPing64.exe local path. 

if ($env:PROCESSOR_ARCHITECTURE -match "AMD64") 
{
    Write-Verbose "x64 machine, PSPING64.exe will be used"
    $pspingFileName = "psping64.exe"
    $pspingDownloadUrl = "https://live.sysinternals.com/psping64.exe"    
}
else 
{
    Write-Verbose "x86 machine, PSPING.exe will be used"
    $pspingFileName = "psping.exe"
    $pspingDownloadUrl = "https://live.sysinternals.com/psping.exe"    
}

# setting local path to script current folder
$pspingLocalFullPath = Join-Path $PSScriptRoot $pspingFileName

# checking if PSPing/64.exe is in the script folder
If (!(Test-Path $pspingLocalFullPath -PathType Leaf))
{
    # setting local path to logpath folder to see if PSPing/64.exe is there (if not in the script folder)
    $pspingLocalFullPath = Join-Path $logpath $pspingFileName

    # checking if PSPing/64.exe is in the logpath folder (if not try to download it)
    If (!(Test-Path $pspingLocalFullPath -PathType Leaf)) 
    {
        # download from Internet.
        If (!$AsJob) 
        {   # In interactive mode, prompt user the file download. 
            # In Job mode, download directly if the file doesn't exist. 
    
            # confirm to download the PSTool.zip
            Write-host "The script will download $pspingFileName from Microsoft Systeminternals web site: $pspingDownloadUrl" -ForegroundColor Cyan
            Write-Host "Please confirm if the download is allowed: Y/N " -ForegroundColor Yellow  -NoNewline
            $keyPressed = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            # Y and Enter key are accepted to download. other keys are not.
            if (($keyPressed.VirtualKeyCode -ne 89) -and ($keyPressed.VirtualKeyCode -ne 13)) 
            {
                # Download is not allowed. 
                Write-Host $keyPressed.Character.ToString().ToUpper()  -ForegroundColor Red
                Write-Host "Download $pspingFileName is not allowed." -ForegroundColor Red
                Write-Host "Please manully download $pspingFileName from $pspingDownloadUrl and copy $pspingFileName to the same folder of this script.`n Run script again."
                Exit -1
            }
    
            Write-Host $keyPressed.Character.ToString().ToUpper()  -ForegroundColor Green
            
        }
        # Download is allowed.
        $webClient = New-Object System.Net.WebClient
        Try 
        {
            Write-Host "Downloading $pspingFileName ..." -ForegroundColor Cyan
            $webClient.DownloadFile($pspingDownloadUrl, $pspingLocalFullPath)
            Write-Host "Downloaded $pspingFileName to folder  $pspingLocalFullPath." -ForegroundColor Cyan
        }
        Catch 
        {
            Write-Host "Cannot download $pspingFileName from Internet. Make sure the Internet connection is available." -ForegroundColor Red    
            Exit -1
        }
    }
}


$command= "$($pspingLocalFullPath) -accepteula -n 1 "+$IPAddress+":"+$port 
Write-Verbose "PSPing Command line:  $command"

Write-Host "`n`nStarting to run $pspingFileName to target $IPAddress @ port $port... `n`n" -ForegroundColor Cyan

while ($killswitch -ne 0) 
{
    $timeStart = Get-Date

    #$result=test-netconnection -port $port -ComputerName $IPAddress
    #$command=$logpath+"\psping.exe -accepteula -n 1 "+$IPAddress+":"+$port 
    $o = Invoke-Expression $command

    If ($o|Select-String "Lost = 1") 
    {
        $failcount++
        $lastline="Connecting to "+$IPAddress+":"+$port+":"
        $result = $o|select-string $lastline 
        #$result = ((get-date).ToUniversalTime()).ToString("yyyy-MM-dd HH:mm:ss")+",ERROR"+","+$IPAddress+","+$port+","+$result +","+$failcount+",times"
        $result = ($timeStart.ToUniversalTime()).ToString("yyyy-MM-dd HH:mm:ss")+",ERROR"+","+$IPAddress+","+$port+","+$result +","+$failcount+",times"
        $result |Out-File $logfile -Encoding utf8 -Append

        Write-AppInsigntTrace $result

        Write-Host $result -Fo Red
    }
    else 
    {
        $lastline="Connecting to "+$IPAddress+":"+$port+":"
        $result = $o|select-string $lastline
        #$result =((get-date).ToUniversalTime()).ToString("yyyy-MM-dd HH:mm:ss")+",SUCCESS"+","+$IPAddress+","+$port+","+$result +",0"
        $result =($timeStart.ToUniversalTime()).ToString("yyyy-MM-dd HH:mm:ss")+",SUCCESS"+","+$IPAddress+","+$port+","+$result +",0"
        $result |Out-File $logfile -Encoding utf8 -Append
        
        Write-AppInsigntTrace $result

        Write-Host $result -Fo Green



        $failcount=0
    }

    # calculate the sleep time based on running time.
    $timeEnd = Get-Date
    $timeSpan = NEW-TIMESPAN -Start $timeStart –End $timeEnd
    $sleepInterval = $interval*1000 - $timeSpan.TotalMilliseconds
    Write-Verbose "Sleep interval: $sleepInterval - Time span: $($timeSpan.Milliseconds) - Start time: $($timeStart.Second).$($timeStart.Millisecond) - End time: $($timeEnd.Second).$($timeEnd.Millisecond)"
    
    if ($sleepInterval -gt 0) 
    {
        Start-Sleep -Milliseconds $sleepInterval
    }
}
